import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-demo-form-validation',
  templateUrl: './demo-form-validation.component.html',
  styleUrls: ['./demo-form-validation.component.css']
})
export class DemoFormValidationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.createFormControls();
    this.createForm();
  }

  proCategoryList: string[] = ["Grocery", "Mobile", "Electronics & Cloths"];
  // avaiInStoreList:string[]=["Big Bazar","DMart","Reliance","Mega Store"];

  avaiInStoreList = [
    { name: "Big Bazar", available: false },
    { name: "DMart", available: false },
    { name: "Reliance", available: false },
    { name: "Mega Store", available: false },
  ]

  myForm: FormGroup;

  proId: FormControl;
  proName: FormControl;
  proCost: FormControl;
  proOnline: FormControl;
  proCategory: FormControl;
  // avaInStore: FormControl;
  avaInStore: FormGroup;


  createFormControls() {
    this.proId = new FormControl('', Validators.required);
    this.proName = new FormControl('', Validators.required);
    this.proCost = new FormControl('', Validators.required);
    this.proOnline = new FormControl('', Validators.required);
    this.proCategory = new FormControl('', Validators.required);
    // this.avaInStore = new FormControl('', Validators.required);

    this.avaInStore = new FormGroup({},(formGroup: FormGroup) => {
      return this.validateStore(formGroup);
    });

    for (let store of this.avaiInStoreList) {
      let control = new FormControl('');
      this.avaInStore.addControl(store.name, control);
    }

  }

  validateStore(formGroup: FormGroup) {
    for (let key in formGroup.controls) {
      if (formGroup.controls.hasOwnProperty(key)) {
        if (formGroup.controls[key].value == true) {
          return null;
        }
      }
    }
    return {
      validateStore: {
        valid: false
      }
    };
  }

  createForm() {
    this.myForm = new FormGroup({
      proId: this.proId,
      proName: this.proName,
      proCost: this.proCost,
      proOnline: this.proOnline,
      proCategory: this.proCategory,
      // avaInStore: this.avaInStore
      avaInStore: this.avaInStore

    });
  }

  printFormData() {
    alert("data submited check on console");
    console.log("ProductId:" + this.proId.value);
    console.log("ProductName:" + this.proName.value);
    console.log("ProductCost:" + this.proCost.value);
    console.log("ProductOnline:" + this.proOnline.value);
    console.log("ProductCategory:" + this.proCategory.value);

    console.log("Product Available in :-");
    for (let s of this.avaiInStoreList) {
      if (s.available === true) {
        console.log(s.name);
      }
    }
  }

  changeAvailablity(store) {
    for (let s of this.avaiInStoreList) {
      if (s.name === store.name) {
        s.available = !s.available;
      }
    }
  }


}
